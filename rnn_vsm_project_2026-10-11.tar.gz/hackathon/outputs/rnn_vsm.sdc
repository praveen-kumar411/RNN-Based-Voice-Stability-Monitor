# ####################################################################

#  Created by Genus(TM) Synthesis Solution 21.14-s082_1 on Sun Oct 11 10:19:18 IST 2026

# ####################################################################

set sdc_version 2.0

set_units -capacitance 1000fF
set_units -time 1000ps

# Set the current design
current_design rnn_vsm_top

create_clock -name "clk" -period 100.0 -waveform {0.0 50.0} [get_ports clk]
set_clock_gating_check -setup 0.0 
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports rst]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports s_tvalid]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[15]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[14]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[13]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[12]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[11]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[10]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[9]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[8]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[7]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[6]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[5]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[4]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[3]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[2]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[1]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {s_tdata[0]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports s_tlast]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports reg_wr]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_addr[3]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_addr[2]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_addr[1]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_addr[0]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[15]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[14]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[13]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[12]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[11]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[10]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[9]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[8]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[7]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[6]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[5]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[4]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[3]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[2]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[1]}]
set_input_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_wdata[0]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports s_tready]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[15]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[14]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[13]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[12]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[11]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[10]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[9]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[8]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[7]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[6]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[5]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[4]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[3]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[2]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[1]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports {reg_rdata[0]}]
set_output_delay -clock [get_clocks clk] -add_delay 10.0 [get_ports irq]
set_wire_load_mode "enclosed"
